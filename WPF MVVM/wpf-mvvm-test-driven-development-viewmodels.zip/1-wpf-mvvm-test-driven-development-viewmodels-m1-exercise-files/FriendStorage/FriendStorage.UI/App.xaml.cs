﻿using System.Windows;

namespace FriendStorage.UI
{
  public partial class App : Application
  {

  }
}
