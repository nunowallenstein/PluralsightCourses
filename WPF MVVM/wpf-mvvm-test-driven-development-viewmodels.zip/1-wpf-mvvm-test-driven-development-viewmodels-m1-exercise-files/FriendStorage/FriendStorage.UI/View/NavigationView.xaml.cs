﻿using System.Windows.Controls;

namespace FriendStorage.UI.View
{
  public partial class NavigationView : UserControl
  {
    public NavigationView()
    {
      InitializeComponent();
    }
  }
}
