﻿using System.Windows;

namespace FriendStorage.UI.View
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
  }
}
