﻿namespace FriendStorage.UI.ViewModel
{
  public class NavigationViewModel : ViewModelBase
  {

  }
}
