﻿namespace FriendStorage.UI.ViewModel
{
  public class MainViewModel : ViewModelBase
  {
 
  }
}
