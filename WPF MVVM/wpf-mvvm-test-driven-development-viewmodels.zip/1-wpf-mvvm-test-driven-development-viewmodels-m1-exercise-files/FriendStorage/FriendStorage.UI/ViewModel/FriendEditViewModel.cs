﻿namespace FriendStorage.UI.ViewModel
{
  public class FriendEditViewModel : ViewModelBase
  {
 
  }
}
